#!/bin/bash
echo $HOME
